﻿#region

using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly : AssemblyTitle ("Тесты для расширения NModel")]
[assembly : AssemblyDescription ("")]
[assembly : AssemblyConfiguration ("")]
[assembly : AssemblyCompany ("")]
[assembly : AssemblyProduct ("Network Simulator")]
[assembly : AssemblyCopyright ("Самунь В.С.")]
[assembly : AssemblyTrademark ("")]
[assembly : AssemblyCulture ("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly : ComVisible (false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly : Guid ("19ac7c46-e99f-4ac4-9400-e5324de26a90")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:

[assembly : AssemblyVersion ("1.0.0.0")]
[assembly : AssemblyFileVersion ("1.0.0.0")]
