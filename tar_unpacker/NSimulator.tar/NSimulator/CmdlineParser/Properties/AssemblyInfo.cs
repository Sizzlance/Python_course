﻿#region

using System.Reflection;
using System.Runtime.InteropServices;

#endregion

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly : AssemblyTitle ("Библиотека парсера командной строки")]
[assembly : AssemblyDescription ("")]
[assembly : AssemblyConfiguration ("")]
[assembly : AssemblyCompany ("Microsoft Corporation")]
[assembly : AssemblyProduct ("Network Simulator")]
[assembly : AssemblyCopyright ("Microsoft Corporation")]
[assembly : AssemblyTrademark ("")]
[assembly : AssemblyCulture ("")]

// Setting ComVisible to false makes the types in this assembly not visible 
// to COM components.  If you need to access a type in this assembly from 
// COM, set the ComVisible attribute to true on that type.

[assembly : ComVisible (false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly : Guid ("d8f72039-6d28-43b0-a7f9-49df7f4ede19")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version 
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Build and Revision Numbers 
// by using the '*' as shown below:
// [assembly: AssemblyVersion("1.0.*")]

[assembly : AssemblyVersion ("1.0.0.0")]
[assembly : AssemblyFileVersion ("1.0.0.0")]
